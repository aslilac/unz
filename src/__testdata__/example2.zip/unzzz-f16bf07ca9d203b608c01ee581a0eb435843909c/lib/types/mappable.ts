export default interface Mappable {
	_begin: number;
	_end: number;
}
