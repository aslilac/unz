# Code of Conduct

Contributors should follow the [Rust Code of Conduct](https://www.rust-lang.org/conduct.html).
